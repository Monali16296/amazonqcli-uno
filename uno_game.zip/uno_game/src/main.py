from game import Game

if __name__ == "__main__":
    # Create and run the game
    game = Game()
    game.run()
